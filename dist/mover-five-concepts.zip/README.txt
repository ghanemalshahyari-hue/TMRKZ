MOVER — Five interactive HTML concepts
Open index.html in a browser.
All facilities, boundaries, requests, and decisions are fictional.
Leaflet is embedded. Offline schematic maps are embedded.
An illustrative regional geographic map from OpenFreeMap / OpenMapTiles / OpenStreetMap is embedded. It runs offline in modern browsers supporting DecompressionStream. It is not a navigation map. All facility names, positions, boundaries, requests, and decisions are fictional.
Demo saves use browser-local storage only. No server or real approval.
Research and thirty questions: questions.html
